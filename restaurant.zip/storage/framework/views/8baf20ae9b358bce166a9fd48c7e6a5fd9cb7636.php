<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 442px;">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Dicount List

        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Category</a></li>
            <li class="active">Category List</li>
        </ol>
        <div class="row">
            <div class="text-center">
                <nav class="tabs">
                    <div class="selector"></div>
                    <a href="#" class="active" id="for-categories"><i class="fa fa-th"></i>For Categories</a>
                    <a href="#" id="for-products"><i class="fa fa-list"></i>For Product</a>
                </nav>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content" style="margin-top: 20px;">

        <div class="row" id="category">
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Discount for Categories</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(route('discount.store')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Category<span class="red-colour">*</span></label>

                                <select name="category_id" id="choose-category" class="form-control">
                                    <option value="">Choose a category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Percentage</label>

                                <input type="number" class="form-control" placeholder="" name="percentage" id="percentege" placeholder="Percentage">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Description<span class="red-colour">*</span></label>

                                <textarea class="form-control" id="" placeholder="Description" name="description" required=""></textarea>
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <div class="col-md-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Discount For Categories</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered dataTable no-footer" id="ttable" role="grid" aria-describedby="ttable_info">

                            <thead>
                                <tr role="row">
                                    <th style="width: 10%">#</th>
                                    <th style="width: 40%">Category Name</th>
                                    <th style="width: 30%">Percentage</th>
                                    <th style="width: 20%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category_discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="odd">
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($discount->category->name); ?></td>
                                    <td><?php echo e($discount->percentage); ?></td>
                                    <td>
                                        <i class="fa fa-trash btn-sm btn-danger" onclick="deleteCategory(<?php echo e($category->id); ?>)"></i>

                                        <a href="<?php echo e(route('category.edit', $category->id)); ?>"><i class="fa fa-edit btn-sm btn-primary"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
                <!-- /.box-body -->
            </div>
        </div>

        <div class="row" id="product">
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Add Discount For Product</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(route('discount.store')); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Category<span class="red-colour">*</span></label>

                                <select name="menu_id" id="choose-product" class="form-control select2">
                                    <option value="">Choose a product</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Percentage</label>

                                <input type="number" class="form-control" placeholder="" name="percentage" id="percentege" placeholder="Percentage">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Description<span class="red-colour">*</span></label>

                                <textarea class="form-control" id="" placeholder="Description" name="description" required=""></textarea>
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <div class="col-md-6">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Discount For Products</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table class="table table-bordered dataTable no-footer" id="ttable" role="grid" aria-describedby="ttable_info">

                            <thead>
                                <tr role="row">
                                    <th style="width: 10%">#</th>
                                    <th style="width: 40%">Product Name</th>
                                    <th style="width: 30%">Percentage</th>
                                    <th style="width: 20%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $product_discounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $discount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="odd">
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($discount->menu->name); ?></td>
                                    <td><?php echo e($discount->percentage); ?></td>
                                    <td>
                                        <i class="fa fa-trash btn-sm btn-danger" onclick="deleteCategory(<?php echo e($category->id); ?>)"></i>

                                        <a href="<?php echo e(route('category.edit', $category->id)); ?>"><i class="fa fa-edit btn-sm btn-primary"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
                <!-- /.box-body -->
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(() => {
        $('#choose-category').select2();
        $('#choose-product').select2();

        $('#product').hide();
    });

    var tabs = $('.tabs');
    var selector = $('.tabs').find('a').length;
    //var selector = $(".tabs").find(".selector");
    var activeItem = tabs.find('.active');
    var activeWidth = activeItem.innerWidth();
    $(".selector").css({
        "left": activeItem.position.left + "px",
        "width": activeWidth + "px"
    });

    $(".tabs").on("click", "a", function(e) {
        e.preventDefault();
        $('.tabs a').removeClass("active");
        $(this).addClass('active');
        var activeWidth = $(this).innerWidth();
        var itemPos = $(this).position();
        $(".selector").css({
            "left": itemPos.left + "px",
            "width": activeWidth + "px"
        });
    });

    $('#for-products').click(() => {
        $('#category').hide();
        $('#product').fadeIn();
    });
    $('#for-categories').click(() => {
        $('#product').hide();
        $('#category').fadeIn();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\youtube\pract\waiter\app\resources\views/discount/index.blade.php ENDPATH**/ ?>