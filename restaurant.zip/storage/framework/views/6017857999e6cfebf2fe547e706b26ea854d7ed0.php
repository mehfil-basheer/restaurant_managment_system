<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 442px;">

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Edit Menus
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Menus</a></li>
            <li class="active">Edit Menu</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-6 col-lg-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">Edit <span class="text text-primary"><?php echo e($menu->name); ?></span></h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(route('menu.update', $menu->id)); ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Name <span class="red-colour">*</span></label>

                                <input type="text" class="form-control" id="" value="<?php echo e(old('name') ?? $menu->name); ?>" placeholder="Enter Item Name" name="name" required="">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Category <span class="red-colour">*</span></label>
                                <select name="category_id" id="menu-category" class="form-control">
                                    <option value="">Select a Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php if($category->id == $menu->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Price per Item<span class="red-colour">*</span></label>

                                <input type="number" min="1" class="form-control" id="" value="<?php echo e(old('price') ?? $menu->price); ?>" placeholder="Enter Price per unit" name="price" required="">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Description</label>

                                <textarea name="description" class="form-control" id="" name="description" placeholder="Description"><?php echo e(old('description') ?? $menu->description); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Image</label>

                                <input type="file" class="form-control" placeholder="" name="image" id="image" value="<?php echo e(old('image') ?? $menu->image); ?>" </div> <div class="form-group">
                                <label for="exampleInputEmail1">Sort Order<span class="red-colour">*</span></label>

                                <input type="number" min="1" class="form-control" id="" value="<?php echo e(old('sort_order') ?? $menu->sort_order); ?>" placeholder="Enter Sort Order" name="sort_order" required="">
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>


        </div>
</div>
</section>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(() => {
        $('#menu-category').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\youtube\pract\waiter\app\resources\views/fooditem/edit.blade.php ENDPATH**/ ?>