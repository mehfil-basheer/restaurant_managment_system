<?php

namespace InstWa;

use Illuminate\Database\Eloquent\Model;

class DeliveryLocationSettings extends Model
{
    //
}
